from lib.codingbase import codingbase

class qwe(codingbase):

    def __init__(self):
        self.encoding_table = {"a":"q", "b":"w", "c":"e", "d":"r", "e":"t",
                               "f":"y", "g":"u", "h":"i", "i":"o", "j":"p",
                               "k":"a", "l":"s", "m":"d", "n":"f", "o":"g",
                               "p":"h", "q":"j", "r":"k", "s":"l", "t":"z",
                               "u":"x", "v":"c", "w":"v", "x":"b", "y":"n",
                               "z":"m"};
        self.decoding_table = dict((v, k) for k,v in self.encoding_table.items());
        pass;
    
    def encode(self, string, extra = None):
        string = string.lower();
        result = [];
        for i in string :
            if i.isalpha():
                result.append(self.encoding_table[i]);
            else:
                result.append(i);
        return ''.join(result);
        

    def decode(self, string, extra = None):
        string = string.lower();
        result = [];
        for i in string:
            if i.isalpha():
                result.append(self.decoding_table[i]);
            else:
                result.append(i);
        return ''.join(result);


if __name__ == "__main__":
    myqwe = qwe();
    print myqwe.decode("kiqlwtfcqgnsoo");
