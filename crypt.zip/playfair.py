from lib.codingbase import codingbase
import string

class playfair(codingbase):

    def __init__(self, key, choosed_table_index = 0):
        key = key + string.ascii_uppercase;
        key = key.lower();
        keyset = set();
        result1 = [];
        for i in key:
            if i not in keyset and i != 'j' and i in string.ascii_uppercase.lower():
                result1.append(i);
                keyset.add(i);

        result2 = [];
        keyset = set();
        for i in key:
            if i not in keyset and i != 'z' and i in string.ascii_uppercase.lower():
                result2.append(i);
                keyset.add(i);
        
        
        result3 = [];
        keyset = set();
        for i in key:
            if i not in keyset and i != 'w' and i in string.ascii_uppercase.lower():
                result3.append(i);
                keyset.add(i);

        self.encoding_table1 = [[result1[0 * 5 + i], result1[1* 5 + i], result1[2* 5 + i], result1[3* 5 + i], result1[4* 5 + i]] for i in xrange(0, 5)]
        self.encoding_table2 = [[result2[0 * 5 + i], result2[1* 5 + i], result2[2* 5 + i], result2[3* 5 + i], result2[4* 5 + i]] for i in xrange(0, 5)]
        self.encoding_table3 = [[result3[0 * 5 + i], result3[1* 5 + i], result3[2* 5 + i], result3[3* 5 + i], result3[4* 5 + i]] for i in xrange(0, 5)]
        self.encoding_table = [self.encoding_table1,self.encoding_table2,self.encoding_table3 ][choosed_table_index];
        print self.encoding_table;
        pass;


    
    def encode(self, encode_string, extra = None):
        encode_string = encode_string.lower();

        if len(encode_string) % 2 == 0:
            result = [];
            for i in xrange(0, len(encode_string), 2):
                if encode_string[i:i + 1] == encode_string[i+1:i+2]:
                    result.append(encode_string[i:i + 1] + 'x');
                    result.append(encode_string[i:i + 1] + 'x');
                else:
                    result.append(encode_string[i:i+2]);
            encode_string = ''.join(result);       
        else:
            ch = encode_string[len(encode_string) - 1: len(encode_string)];
            encode_string = encode_string[0: len(encode_string) - 1];
            result = [];
            for i in xrange(0, len(encode_string), 2):
                if encode_string[i:i + 1] == encode_string[i+1:i+2]:
                    result.append(encode_string[i:i + 1] + 'x');
                    result.append(encode_string[i:i + 1] + 'x');
                else:
                    result.append(encode_string[i:i+2]);
            encode_string = ''.join(result);
            encode_string += (ch + 'x');

        result = [];
        for index in xrange(0, len(encode_string), 2):    
            x1 = 0;
            y1 = 0;
            for i in xrange(0, 5):
                for j in xrange(0, 5):
                    if self.encoding_table[i][j] == encode_string[index: index + 1]:
                        x1 = i;
                        y1 = j;
                        break;
            x2 = 0;
            y2 = 0;
            for i in xrange(0, 5):
                for j in xrange(0, 5):
                    if self.encoding_table[i][j] == encode_string[index + 1: index + 2]:
                        x2 = i;
                        y2 = j;
                        break;
            if x1 == x2 and y1 != y2:
                result.append(self.encoding_table[x1][(y1 + 1) % 5]);
                result.append(self.encoding_table[x2][(y2 + 1) % 5]);
            elif y1 == y2 and x1 != x2:
                result.append(self.encoding_table[(x1 + 1) % 5][y1]);
                result.append(self.encoding_table[(x2 + 1) % 5][y2]);
            elif y1 != y2 and x1 != x2:
                myx = x1 if x1 < x2 else x2;
                if myx == x1:
                    result.append(self.encoding_table[x1][y2]);
                    result.append(self.encoding_table[x2][y1]);
                else:
                    result.append(self.encoding_table[x2][y1]);
                    result.append(self.encoding_table[x1][y2]);
        return ''.join(result)

    def decode(self, decode_string, extra = None):
        decode_string = decode_string.lower();
        result = [];
        for index in xrange(0, len(decode_string), 2):
            x1 = 0;
            y1 = 0;
            for i in xrange(0, 5):
                for j in xrange(0, 5):
                    if self.encoding_table[i][j] == decode_string[index: index + 1]:
                        x1 = i;
                        y1 = j;
                        break;
            x2 = 0;
            y2 = 0;
            for i in xrange(0, 5):
                for j in xrange(0, 5):
                    if self.encoding_table[i][j] == decode_string[index + 1: index + 2]:
                        x2 = i;
                        y2 = j;
                        break;
            if x1 == x2 and y1 != y2:
                result.append(self.encoding_table[x1][(y1 + 4) % 5]);
                result.append(self.encoding_table[x2][(y2 + 4) % 5]);
            elif y1 == y2 and x1 != x2:
                result.append(self.encoding_table[(x1 + 4) % 5][y1]);
                result.append(self.encoding_table[(x2 + 4) % 5][y2]);
            elif y1 != y2 and x1 != x2:
                myx = x1 if x1 < x2 else x2;
                if myx == x1:
                    result.append(self.encoding_table[x1][y2]);
                    result.append(self.encoding_table[x2][y1]);
                else:
                    result.append(self.encoding_table[x2][y1]);
                    result.append(self.encoding_table[x1][y2]);
        return ''.join(result)
            


if __name__ == "__main__":
    myplayfair = playfair("shiyanb", 2);
    #print myplayfair.encode('tcfxplayafirisafirplay');
    print myplayfair.decode("KQSAMFPAOPMFPA");
