from lib.codingbase import codingbase

class ADFGX(codingbase):

    def encode(self, string, extra = None):
        pass;

    
    def decode(self, string, extra = None):
        pass;
