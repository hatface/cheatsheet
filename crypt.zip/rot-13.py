

def rot13(string):
    return string.encode('rot-13');


if __name__ =="__main__":
    print rot13("gur rkgebireg ybbxf ng gur BGURE thl'f fubrf.");
