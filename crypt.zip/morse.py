from lib.codingbase import codingbase

class morse(codingbase):

    morseCharacters = [".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", 
	    ".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", 
	    ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--.." ];
    morseDigits = ["-----", ".----", "..---", "...--", "....-", 
	    ".....", "-....", "--...", "---..", "----." ];

    encoding_table = dict();
    decoding_table = dict();

    def __init__(self):
        for i in xrange(ord('a'), ord('z') + 1):
            self.encoding_table[chr(i)] = self.morseCharacters[i - ord('a')];
            self.decoding_table[self.morseCharacters[i - ord('a')]] = chr(i);
        for i in xrange(0, 10):
            self.encoding_table[str(i)] = self.morseDigits[i];
            self.decoding_table[self.morseDigits[i]] = str(i);
        self.encoding_table.update({".":".-.-.-",
                                    ":":"---...",
                                    ",":"--..--",
                                    ";":"-.-.-.",
                                    "?":"..--..",
                                    "=":"-...-" ,
                                    "'":".----.",
                                    "/":"-..-." ,
                                    "!":"-.-.--",
                                    "-":"-....-",
                                    "_":"..--.-",
                                    "\"":".-..-.",
                                    "(":"-.--." ,
                                    ")":"-.--.-",
                                    "$":"...-..-",
                                    "&":"...."  ,
                                    "@":".--.-.",
                                    "+":".-.-."});
        self.decoding_table.update({".-.-.-":".",
                                    "---...":":",
                                    "--..--":",",
                                    "-.-.-.":";",
                                    "..--..":"?",
                                    "-...-":"=",
                                    ".----.":"'",
                                    "-..-.":"/",
                                    "-.-.--":"!",
                                    "-....-":"-",
                                    "..--.-":"_",
                                    ".-..-.":"\"",
                                    "-.--.":"(",
                                    "-.--.-":")",
                                    "...-..-":"$",
                                    "....":"&",
                                    ".--.-.":"@",
                                    ".-.-.":"+"});
    
    def encode(self, string, extra = None):
        string = string.lower();
        result = [];
        for  i in string:
            if self.encoding_table.get(i) == None:
                result.append(i);
                result.append(' ');
                continue;
            result.append(self.encoding_table[i]);
            result.append(' ');
        return ''.join(result);        

    def decode(self, string, extra = None):
        string = string.lower();
        string = string.split();
        result = [];
        for i in string :
            if self.decoding_table.get(i) == None:
                result.append(i);
                continue;
            result.append(self.decoding_table[i]);
        return ''.join(result);


if __name__ == "__main__":
    mymorse = morse();
    print  mymorse.decode("-.. .-- .-.- . --.-");
