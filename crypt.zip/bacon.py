from lib.codingbase import codingbase

class bacon(codingbase):

    def __init__(self):
        self.encoding_table = dict(A='aaaaa',B='aaaab',C='aaaba',D='aaabb',E='aabaa',F='aabab',
                G='aabba',H='aabbb',I='abaaa',J='abaab',K='ababa',L='ababb',
                M='abbaa',N='abbab',O='abbba',P='abbbb',Q='baaaa',R='baaab',
                S='baaba',T='baabb',U='babaa',V='babab',W='babba',X='babbb',
                Y='bbaaa',Z='bbaab',a='aaaaa'.upper(),b='aaaab'.upper(),c='aaaba'.upper(),d='aaabb'.upper(),
                                   e='aabaa'.upper(),f='aabab'.upper(),
                g='aabba'.upper(),h='aabbb'.upper(),i='abaaa'.upper(),j='abaab'.upper(),k='ababa'.upper(),l='ababb'.upper(),
                m='abbaa'.upper(),n='abbab'.upper(),o='abbba'.upper(),p='abbbb'.upper(),q='baaaa'.upper(),r='baaab'.upper(),
                s='baaba'.upper(),t='baabb'.upper(),u='babaa'.upper(),v='babab'.upper(),w='babba'.upper(),x='babbb'.upper(),
                y='bbaaa'.upper(),z='bbaab'.upper())
        self.decoding_table = dict((v, k) for k, v in self.encoding_table.items());

    def encode(self, string, extra = None):
        result = [];
        for i in string:
            if i.isalpha():
                result.append(self.encoding_table[i]);
            else:
                result.append(i);
        return ' '.join(result)                
        

    def decode(self, string, extra = None):
        result = [];
        for i in string.split() :
            if self.decoding_table.get(i) == None:
                result.append(i);
                continue;
            result.append(self.decoding_table[i]);
        return ''.join(result);
        

if __name__ == "__main__":
    mybacon = bacon();    
    print mybacon.decode('BAABA ABBAA AAAAA ABABB ABABB BAABA BAABB ABBBA ABBAB AABAA'.lower());
