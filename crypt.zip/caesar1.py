#-*-coding=utf-8-*-

def caesar(string, length=1):
    if length < 0:
        length = -((-length) % 26) + 26;
    else:
        length = length % 26;
    
    result_array = [];
    for item in string:
        if item.islower():
            item = chr((ord(item) - ord('a') + length) % 26 + ord('a'));
        elif item.isupper():
            item = chr((ord(item) - ord('A') + length) % 26 + ord('A'));
        elif item.isdigit():
            item = chr((ord(item) - ord('0') + length) % 10 + ord('0'));
        result_array.append(item);
    return ''.join(result_array);


if __name__ == "__main__":
    for i in xrange(0, 25):
        print caesar("iodj{fe1e684g8944d92ei134g3g2f42gf27f}", i);

